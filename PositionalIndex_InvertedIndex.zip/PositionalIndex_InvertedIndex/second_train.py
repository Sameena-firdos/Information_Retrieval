import pickle
import re
import math
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import OrderedDict

import glob

directory_list=['rec.motorcycles/*','comp.graphics/*']
#directory_list=['test/*']
posting_list={}
dict_docids={}
doc_id=0


def pre_processing(id,file):
	temp_dict={}
	counter=0
	global posting_list
	try:
		text = open(file, 'r')
		text=text.read()
	except:
		return file
	try:
		first, second = text.split('\n\n',1)
	except:
		second=text
	text=second.lower()
	#print text,"sad"
	try:
		se=sent_tokenize(text)
	except:
		return file

	for sent in se:
		try:
			word=word_tokenize(sent)
			#print word
			#word=term_expansion(word)
			'''stop_words = set(stopwords.words('english'))
			word = [t for t in sent if not t in stop_words]'''
		except:
			continue
		for i in range(0,len(word)):
			
			pro=re.compile(r'.*[A-Za-z]+.*')
			match = re.search(pro, word[i])
			if match != None:
				word[i] = re.sub(r'[0-9!@#$%^&*()_+={}:;<>?/\|.,-]*',"",word[i])
				#pro=re.compile(r'[a-z]*[\'][a-z]*')
				#match = re.search(pro, word[i]) 
				if 1==1:
					if len(word[i])!=0:
						counter+=1
						try:
							'''if id not in dict_index[i]:
								dict_index[i].append(id)
								dict_len[i]+=1'''
							temp_dict[word[i]].append(counter)



						except:
							temp_dict[word[i]]=[]
							temp_dict[word[i]].append(counter)
							'''dict_index[i]=[]
							dict_len[i]=1
							dict_index[i].append(id)'''
	for key in temp_dict:
		try:
			posting_list[key][id]=temp_dict[key]

		except:
			posting_list[key]=OrderedDict()
			posting_list[key][id]=temp_dict[key]
	#print posting_list







def data_extraction():
	global directory_list;global dict_docids;global doc_id;global posting_list

	for dire in directory_list:
		files=glob.glob(dire)
		for file in files:
			doc_id+=1
			print file
			dict_docids[doc_id]=file
			pre_processing(doc_id,file)
	print posting_list

def data_save():
	global dict_docids;global posting_list
	dbfile = open('positional_index', 'wb') 
	pickle.dump(posting_list, dbfile)
	dbfile.close()
	dbfile = open('positional_index_docid', 'wb') 
	pickle.dump(dict_docids, dbfile)
	dbfile.close()



data_extraction()
data_save()








