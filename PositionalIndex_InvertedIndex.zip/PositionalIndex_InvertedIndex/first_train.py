import pickle
import re
import math
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import OrderedDict
import glob
directory_list=['rec.motorcycles/*','rec.sport.baseball/*',
'alt.atheism/*','comp.graphics/*','comp.os.ms-windows.misc/*',
'comp.sys.ibm.pc.hardware/*','comp.sys.mac.hardware/*',
'comp.windows.x/*','misc.forsale/*','rec.autos/*','rec.sport.hockey/*',
'sci.crypt/*','sci.electronics/*','sci.med/*','sci.space/*',
'soc.religion.christian/*','talk.politics.guns/*','talk.politics.mideast/*',
'talk.politics.misc/*','talk.religion.misc/*']


#directory_list=['test/*']
dict_docids=OrderedDict()
dict_index=OrderedDict()
dict_len=OrderedDict()
doc_id=0


def pre_processing(id,file):
	global dict_index
	global dict_len
	try:
		text = open(file, 'r')
		text=text.read()
	except:
		return file
	try:
		first, second = text.split('\n\n',1)
	except:
		second=text
	text=second.lower()
	try:
		se=sent_tokenize(text)
	except:
		return file
	
	#lis=[]
	for sent in se:

		
		try:
			sent=word_tokenize(sent)
			stop_words = set(stopwords.words('english'))
			word = [t for t in sent if not t in stop_words]

		except:
			continue
		for i in word:
			pro=re.compile(r'.*[A-Za-z]+.*')
			match = re.search(pro, i)
			if match != None:
				i = re.sub(r'[0-9!@#$%^&*()_+={}:;<>?/\|.,-]*',"",i)
				pro=re.compile(r'[a-z]*[\'][a-z]*')
				match = re.search(pro, i) 
				if match==None:
					if len(i)!=1 and len(i)!=2 and len(i)!=0:
						#lis.append(i)
						#print i
						try:
							if id not in dict_index[i]:
								dict_index[i].append(id)
								dict_len[i]+=1

						except:
							dict_index[i]=[]
							dict_len[i]=1
							dict_index[i].append(id)

	#print lis,file
	'''for key in dict_index:
		print key," ",dict_index[key],dict_len[key]'''




def extract_data():
	global doc_id
	global directory_list
	global dict_docids

	for dire in directory_list:
		files=glob.glob(dire)
		for file in files:
			doc_id+=1
			print file
			dict_docids[doc_id]=file
			num=pre_processing(doc_id,file)
			break
			#print num
			#break
		#break
	#print dict_docids

def save_data():
	global dict_index;global dict_len;global dict_docids;
	#db={}
	#db["unigram"]=dic_unigram
	dbfile = open('posting_list', 'wb') 
	pickle.dump(dict_index, dbfile)
	dbfile.close()
	dbfile = open('list_length', 'wb') 
	pickle.dump(dict_len, dbfile)
	dbfile.close()
	dbfile = open('doc_ids', 'wb') 
	pickle.dump(dict_docids, dbfile)
	dbfile.close()
	



extract_data()
save_data()




