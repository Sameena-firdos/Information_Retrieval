import pickle
import re
import math
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import OrderedDict
import glob
from nltk.stem import WordNetLemmatizer
from num2words import num2words 
import math 
import numpy as np
from numpy import dot
from numpy.linalg import norm

title_dict={}
dict_docids={}
word_matrix={}
dict_index={}
doc_word_dict={}
doc_id=0
vocab=[]
title_matrix={}


def title(file):
	global title_dict

	text = open(file, 'r')
	text=text.read()

	text=text.split("\n")

	for t in text:
		s=t.split("<BR><TD> ")
		try:
			if s[1]:
				print "" #title
		except:
			pass
		result = re.search('<A HREF(.+)>(.+)</A>', t)
		if result:
			#result=result.split(">")
			result=result.group(0)
			result=result.split(">")
			result=result[1].split("<")
			#print result[0]	#file name
		try:
			result[0]=result[0].strip()
			s[1]=s[1].strip()
			title_dict[result[0]]=s[1]
		except:
			pass

def title_dict_pickle_save(dictionary,name):
	dbfile = open(name, 'wb') 
	pickle.dump(dictionary, dbfile)
	dbfile.close()


	
def title_data():
	title_file=["index.html","index_sre.html"]
	for f in title_file:
		title(f)
	#title_dict_pickle_save()



def pre_processing_data(id,file):
	global word_matrix;global dict_index;global doc_word_dict;global vocab;global doc_id
	try:
		text = open(file, 'r')
		text=text.read()
	except:
		return file
	text=text.lower()
	try:
		se=sent_tokenize(text)
	except:
		return file
	
	#lis=[]
	lem=WordNetLemmatizer()
	for sent in se:
		try:
			sent=word_tokenize(sent)
		except:
			continue
		for i in sent:
			#print i
			i=i.strip()


			pro=re.compile(r'.*')
			match = re.search(pro, i)
			if match != None:
				i = re.sub(r'[#!@$%^&*()_+={}:;<>?/\|.,-]*',"",i)
				pro=re.compile(r'[a-z]*[\'][a-z]*')
				match = re.search(pro, i) 
				if match==None:
					if len(i)!=0:
						try:
							i=num2words(i)
						except:
							pass
						i=word_tokenize(i)
						for val in i:

							try:
								val=lem.lemmatize(val)
								val=re.sub(r'[^\x00-\x7f]',"",val)
							except:
								pass

							if val not in vocab:
								vocab.append(val)

							try:
								if id not in dict_index[val]:
									dict_index[val].append(id)
							except:
								
								dict_index[val]=[]
								dict_index[val].append(id)
							try:
								word_matrix[val]
							except:
								word_matrix[val]={}
							try:		
								word_matrix[val][id]+=1
							except:
								word_matrix[val][id]=1
							try:
								doc_word_dict[id].add(val)
							except:
								doc_word_dict[id]=set()
								doc_word_dict[id].add(val)




def data_fill(c_matrix,t_matrix,f_tfidf,s_tfidf,t_tfidf,a_tfidf):
	global dict_index;global doc_word_dict;global doc_id;global dict_docids
	#print dict_index
	#print word_matrix
	#print doc_word_dict
	print "filling1"
	title_dict_pickle_save(dict_index,"word_doc_list") #stores words and its corrsponding unique docs
	#///title_dict_pickle_save(word_matrix,"count_matrix") #stores word and doc count
	print "filling2"
	title_dict_pickle_save(doc_word_dict,"document_matrix") #for jackard coefficient
	print "filling3"
	title_dict_pickle_save(dict_docids,"document_ids") #name of docid

	r1={}
	r1["vocab"]=vocab
	r1["total_doc"]=doc_id  #this is one extra doc id
	title_dict_pickle_save(r1,"vocabulary")
	r2={}
	r2["c_matrix"]=c_matrix
	r2["t_matrix"]=t_matrix
	r2["f_tf"]=f_tfidf
	r2["s_tf"]=s_tfidf
	r2["t_tf"]=t_tfidf
	r2["a_tf"]=a_tfidf
	print "filling4"
	title_dict_pickle_save(r2,"matrix")
	print doc_id

def load_data(name):
	a= open(name, 'rb')
	p= pickle.load(a)
	return p

def data_extract():
	global dict_index;global doc_word_dict;global doc_id;global dict_docids;global vocab

	dict_index=load_data("word_doc_list");
	doc_word_dict=load_data("document_matrix");dict_docids=load_data("document_ids")
	r1=load_data("vocabulary");vocab=r1["vocab"];doc_id=r1["total_doc"]
	r2=load_data("matrix");c_matrix=r2["c_matrix"];t_matrix=r2["t_matrix"];
	f_tfidf=r2["f_tf"];s_tfidf=r2["s_tf"];t_tfidf=r2["t_tf"];a_tfidf=r2["a_tf"]
	return c_matrix,t_matrix,f_tfidf,s_tfidf,t_tfidf,a_tfidf

def count_vector_data_extraction():
	global dict_docids;global doc_id
	
	files=glob.glob("stories/*")
	for file in files:
		
		print file
		f=file.split("/")

		dict_docids[doc_id]=f[1]
		num=pre_processing_data(doc_id,file)
		doc_id+=1
	

		
def title_dictionary_creation():
	global dict_docids;global vocab;global title_dict;global title_matrix
	
	lem=WordNetLemmatizer()
	for id in dict_docids:
		text=title_dict[dict_docids[id]]
		text=text.lower()
		#print text,dict_docids[id]
		try:
			sent=word_tokenize(text)
		except:
			continue
		for i in sent:
			i=i.strip()

			pro=re.compile(r'.*')
			match = re.search(pro, i)
			if match != None:
				i = re.sub(r'[#!@$%^&*()_+={}:;<>?/\|.,-]*',"",i)
				pro=re.compile(r'[a-z]*[\'][a-z]*')
				match = re.search(pro, i) 
				if match==None:
					if len(i)!=0:
						try:
							i=num2words(i)
						except:
							pass
						i=word_tokenize(i)
						for val in i:
							try:
								val=lem.lemmatize(val)
								val=re.sub(r'[^\x00-\x7f]',"",val)
							except:
								pass
							try:
								title_matrix[val]
							except:
								title_matrix[val]={}
							try:		
								title_matrix[val][id]+=1
							except:
								title_matrix[val][id]=1
	#print title_matrix





def matrix_creation():
	global vocab;global title_matrix;global word_matrix;global doc_id
	
	c_matrix=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]
	t_matrix=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]

	#print vocab
	for i in range(0,doc_id):
		for v in range(0,len(vocab)):
			
			try:
				c_matrix[i][v]=word_matrix[vocab[v]][i]
			except:
				
				c_matrix[i][v]=0

			try:
				if(word_matrix[vocab[v]][i]>=title_matrix[vocab[v]][i]):
					t_matrix[i][v]=(.7*title_matrix[vocab[v]][i])+(.3*(word_matrix[vocab[v]][i]-title_matrix[vocab[v]][i]))
				else:
					t_matrix[i][v]=(.7*title_matrix[vocab[v]][i])
			except:
				
				try:
					t_matrix[i][v]=(.3*(word_matrix[vocab[v]][i]))
				except:
					
					t_matrix[i][v]=0


	#print np.array(c_matrix)[:,:5]
	#print np.array(t_matrix)[:,:5]
	return c_matrix,t_matrix


def first_tfidf(c_matrix,t_matrix):
	global vocab;global doc_id;global dict_index
	#f*1
	f_tfidf=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]
	
	for i in range(0,doc_id):
		for v in range(0,len(vocab)):
			try:
				
				tf_idf=float(math.log((1.0*doc_id)/(len(dict_index[vocab[v]])),10))
				
				f_tfidf[i][v]=c_matrix[i][v]*tf_idf
			except:
				
				f_tfidf[i][v]=0

	#print np.array(f_tfidf)[:,:15]
	return f_tfidf




def second_tfidf(c_matrix,t_matrix):
	global vocab;global doc_id;global dict_index
	#(1+logtf) * (logn/df)
	s_tfidf=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]
	
	for i in range(0,doc_id):
		for v in range(0,len(vocab)):
			try:
				
				tf_idf=float(math.log((1.0*doc_id)/(len(dict_index[vocab[v]])),10))
				
				tf=(1+math.log(c_matrix[i][v],10))
				s_tfidf[i][v]=tf*tf_idf
			except:
				
				s_tfidf[i][v]=0

	#print np.array(s_tfidf)[:,:15]
	return s_tfidf



def third_tfidf(c_matrix,t_matrix):
	global vocab;global doc_id;global dict_index
	#f/doclen * (1+log(n/df))
	t_tfidf=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]
	#print c_matrix
	for i in range(0,doc_id):
		sum=0
		for j in range(0,len(vocab)):
			sum+=c_matrix[i][j]
		for v in range(0,len(vocab)):
			try:
				tf_idf=float(math.log((1.0*doc_id)/(len(dict_index[vocab[v]])),10))
				
				t_tfidf[i][v]=((1.0*c_matrix[i][v])/sum)*tf_idf
			except:
				
				t_tfidf[i][v]=0

	#print np.array(t_tfidf)[:,:15]
	return t_tfidf

def augument_tfidf(c_matrix,t_matrix):
	global vocab;global doc_id;global dict_index
	a_tfidf=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]
	for i in range(0,doc_id):
		max_value=max(c_matrix[i])
		for v in range(0,len(vocab)):
			tf=0.5+(0.5*((c_matrix[i][v])/max_value))
			try:
				tf_idf=float(math.log((1.0*doc_id)/(len(dict_index[vocab[v]])),10))
				
				a_tfidf[i][v]=tf*tf_idf
			except:
				#print "in augument"
				
				a_tfidf[i][v]=0
	#print a_tfidf
	return a_tfidf






def query_preprocessing(text):
	q=[]
	#print text
	text=text.lower()
	try:
		se=word_tokenize(text)
	except:
		return ""

	lem=WordNetLemmatizer()
	#print se
	for i in se:
		i=i.strip()
		
		pro=re.compile(r'.*')
		match = re.search(pro, i)
		if match != None:
			i = re.sub(r'[#!@$%^&*()_+={}:;<>?/\|.,-]*',"",i)
			pro=re.compile(r'[a-z]*[\'][a-z]*')
			match = re.search(pro, i) 
			if match==None:
				if len(i)!=0:
					#print i
					try:
						i=num2words(i)
					except:
						
						pass
					i=word_tokenize(i)
					for val in i:
						
						try:
							val=lem.lemmatize(val)
							val=re.sub(r'[^\x00-\x7f]',"",val)
							q.append(val)
							
						except:
							
							pass
	return q

def jackerd_coefficient(query,k):
	global doc_word_dict;global vocab;global doc_id;global dict_docids
	print "jackerd coefficient"
	s=set(query)
	#print s
	jc=[]
	for id in range(0,doc_id):
		#print doc_word_dict[id]
		v=(1.0*len(s & doc_word_dict[id]))/len(s | doc_word_dict[id])
		jc.append([v,id])
	jc.sort()
	#print jc
	#print jc
	for i in range(len(jc)-1,-1,-1):
		print jc[i][0],dict_docids[jc[i][1]]
		k-=1
		if k==0:
			break
	print 

		
def query_matrix(query,c_matrix,t_matrix):
	global vocab;global doc_id;global dict_index
	q_tfidf=[]
	for i in range(0,len(vocab)):
		q_tfidf.append(0)
	q_count={}
	for i in query:
		try:
			q_count[i]+=1
		except:
			q_count[i]=1
	for v in range(0,len(vocab)):
		if vocab[v] in query:
			tf=(1+math.log(q_count[vocab[v]],10))
			#print dict_index[vocab[v]],vocab[v],tf
			idf=float(math.log((1.0*doc_id)/(len(dict_index[vocab[v]])),10))
			q_tfidf[v]=idf*tf
	#print q_tfidf
	return q_tfidf
def score_calculation(weight_matrix,query):
	global vocab;global doc_id;global dict_index
	m=[]
	for i in range(0,doc_id):
		m.append(0)
	for d in range(0,doc_id):
		for v in range(0,len(vocab)):
			if vocab[v] in query:
				m[d]+=weight_matrix[d][v]
	return m

def tfidf_score_calculation(c_matrix,t_matrix,q_tfidf,f_tfidf,s_tfidf,t_tfidf,a_tfidf,query,k):
	
	global vocab;global doc_id;global dict_index;global dict_docids
	f_score=score_calculation(f_tfidf,query)
	s_score=score_calculation(s_tfidf,query)
	t_score=score_calculation(t_tfidf,query)
	a_score=score_calculation(a_tfidf,query)
	a=[];b=[];c=[];e=[]
	k1=k;k2=k;k3=k;k4=k
	for i in range(0,len(f_score)):
		a.append([f_score[i],i])
	a.sort()


	print "score for first tfidf "
	for i in range(len(a)-1,-1,-1):
		print a[i][0],dict_docids[a[i][1]]
		k1-=1
		if k1==0:
			break
	


	for i in range(0,len(s_score)):
		b.append([s_score[i],i])
	b.sort()
	print
	print "score for second tfidf"
	for i in range(len(b)-1,-1,-1):
		print b[i][0],dict_docids[b[i][1]]
		k2-=1
		if k2==0:
			break


	for i in range(0,len(t_score)):
		c.append([t_score[i],i])
	c.sort()
	print
	print "score for third tfidf"
	for i in range(len(c)-1,-1,-1):
		print c[i][0],dict_docids[c[i][1]]
		k3-=1
		if k3==0:
			break
	print "##########################"
	for i in range(0,len(a_score)):
		e.append([a_score[i],i])
	e.sort()


	print "score for augumented tfidf "
	for i in range(len(e)-1,-1,-1):
		print e[i][0],dict_docids[e[i][1]]
		k4-=1
		if k4==0:
			break


	score=title_weight(s_tfidf,k,t_matrix,query)
	d=[]
	for i in range(0,len(score)):
		d.append([score[i],i])
	d.sort()
	print
	print "score for with title weight"
	for i in range(len(d)-1,-1,-1):
		print d[i][0],dict_docids[d[i][1]]
		k-=1
		if k==0:
			break



def title_weight(matrix,k,t_matrix,query):
	global vocab;global doc_id;global dict_index
	m=[]
	for i in range(0,doc_id):
		m.append(0)
	for d in range(0,doc_id):
		for v in range(0,len(vocab)):
			if vocab[v] in query:
				m[d]+=matrix[d][v]*t_matrix[d][v]
	return m


def tfidf_vector_score(c_matrix,t_matrix,q_tfidf,f_tfidf,s_tfidf,t_tfidf,query,k_val):
	global vocab;global doc_id;global dict_index;global dict_docids
	d1=[]
	d2=[]
	k1=k_val;k2=k_val
	for d in range(0,doc_id):
		a=np.array(q_tfidf)
		b=np.array(s_tfidf[d])
		if norm(a)!=0 and norm(b)!=0:

			s= a.dot(b)/(float)(norm(a)*norm(b))
			d1.append([s,d])
		else:
			d1.append([0,d])

	d1.sort()
	print
	print "Similarity vector space document retirval"
	for i in range(len(d1)-1,-1,-1):
		print d1[i][0],dict_docids[d1[i][1]]
		k1-=1
		if k1==0:
			break
	print

	print "Similarity vector space document retrieval with title weitage"
	tm_matrix=[[0 for i in range(0,len(vocab))]for j in range(0,doc_id)]

	#print vocab
	for i in range(0,doc_id):
		for v in range(0,len(vocab)):
			tm_matrix[i][v]=s_tfidf[i][v]*t_matrix[i][v]

	for d in range(0,doc_id):
		a=np.array(q_tfidf)
		b=np.array(tm_matrix[d])
		if norm(a)!=0 and norm(b)!=0:
			s= a.dot(b)/(float)(norm(a)*norm(b))
			d2.append([s,d])
		else:
			d2.append([0,d])

	d2.sort()
	for i in range(len(d2)-1,-1,-1):
		print d2[i][0],dict_docids[d2[i][1]]
		k2-=1
		if k2==0:
			break


c_matrix,t_matrix,f_tfidf,s_tfidf,t_tfidf,a_tfidf=data_extract()
print "enter query "
query=raw_input()
#query="THE SEVEN VOYAGES OF SINBAD THE SAILOR"
print "enter k value"
k_val=input()
#k_val=2
query=query_preprocessing(query)
'''title_data()
print "done1"
count_vector_data_extraction()
print "done2"
title_dictionary_creation()
print "done3"
c_matrix,t_matrix=matrix_creation()
print "done4"
f_tfidf=first_tfidf(c_matrix,t_matrix)
print "done5"
s_tfidf=second_tfidf(c_matrix,t_matrix)
print "done6"
t_tfidf=third_tfidf(c_matrix,t_matrix)
print "done7"
a_tfidf=augument_tfidf(c_matrix,t_matrix)
print "done8"
data_fill(c_matrix,t_matrix,f_tfidf,s_tfidf,t_tfidf,a_tfidf)
'''
q_tfidf=query_matrix(query,c_matrix,t_matrix)
jackerd_coefficient(query,k_val)
tfidf_score_calculation(c_matrix,t_matrix,q_tfidf,f_tfidf,s_tfidf,t_tfidf,a_tfidf,query,k_val)
tfidf_vector_score(c_matrix,t_matrix,q_tfidf,f_tfidf,s_tfidf,t_tfidf,query,k_val)
