Here I worked on Soc-Sign-BItcoin dataset by converting it to graph.
Question1 make some analysis like centrality measures.
Question2 implement pagerank anf HITs algorithm