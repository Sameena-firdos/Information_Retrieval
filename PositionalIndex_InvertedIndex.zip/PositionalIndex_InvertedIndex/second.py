import pickle
import re
import math
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import OrderedDict
import operator

positional_index={}
doc_ids={}

def data_loading():
	global positional_index;global doc_ids

	a= open('positional_index', 'rb')
	positional_index= pickle.load(a)

	b= open('positional_index_docid', 'rb')
	doc_ids= pickle.load(b)



def query_processing(query):
	global positional_index;global doc_ids
	#print positional_index
	word=word_tokenize(query)

	temp_dict=[]
	for value in word:
		try:
			#print value
			temp_dict.append([len(positional_index[value].keys()),positional_index[value].keys()])
		except:
			print "no document found"
			return
	temp_dict.sort()
	#print temp_dict



	temp_list=[]
	for i in range(0,len(temp_dict)):
		temp_list.append(temp_dict[i][1])
	#print temp_list

	common_list=[]
	#print temp_list

	#common list for matching document
	if(len(temp_list)==1):
		#print temp_dict[sorted_list[0][0]]
		common_list.extend(temp_list[0])

	else:
		l1=temp_list[0]
		l2=temp_list[1]
		l3=[]
		i=0
		j=0
		#print l1
		while(i<len(l1) and j<len(l2)):
			
			if l1[i]<l2[j]:
				i+=1
			elif l1[i]==l2[j]:
				l3.append(l1[i])
				i+=1
				j+=1
			else:
				j+=1
		
		
		for i in l3:
			common_list.append(i)

		for i in range(2,len(temp_list)):
			l1=temp_list[i]
			l3=[]
			i=0
			j=0
			#print l1
			while(i<len(l1) and j<len(common_list)):
				
				if l1[i]<common_list[j]:
					i+=1
				elif l1[i]==common_list[j]:
					l3.append(l1[i])
					i+=1
					j+=1
				else:
					j+=1
			common_list=[]
			common_list.extend(l3)
	

	#print common_list
	matching(common_list,query)


def matching(common_list,query):
	global positional_index; global doc_ids
	match=0
	l=[]
	query=word_tokenize(query)
	
	for doc in common_list:
		match=0
		for i in range(0,len(query)):
			value=0
			for j in range(i+1,len(query)):
				flag=0
				for index in positional_index[query[i]][doc]:
					if index+(j-i) in positional_index[query[j]][doc]:
						flag=1
						break
					else:
						continue
				if flag==1:
					value+=1
			if value==(len(query)-i-1):
				match+=1
		if match==len(query):
			l.append(doc)
	if len(l)==0:
		print "no matching documents"
		return
	print "list of document id matched ",l
	print "document name are "
	for i in l:
		print i,"->",doc_ids[i]





















print "enter the query"
query=raw_input()
#query='for one thought you told'
#query='say'
#query="I'm an asshole in many times on the"
query=query.lower()
data_loading()
query_processing(query)













