import pickle
import re
import math
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import OrderedDict
import operator


posting_lists={}
list_length={}
doc_ids={}
comparisions=0



def load_data():
	global posting_lists;global list_length;global doc_ids
	a= open('posting_list', 'rb')
	posting_lists= pickle.load(a)

	b= open('list_length', 'rb')
	list_length= pickle.load(b)

	c= open('doc_ids', 'rb')
	doc_ids= pickle.load(c)
	

def and_handle(word,universal):
	global posting_lists;global list_length;global doc_ids;global comparisions
	temp_dict={}
	temp_len={}
	word=word.split('and');word=[i.strip() for i in word]
	#print word
	#print word
	for value in word:
		
		if 'not' not in value:
			temp_dict[value]=[]
			temp_len[value]=0
			try:
				temp_dict[value]=posting_lists[value]
				temp_len[value]=list_length[value]
				#print value,temp_dict[value]
			except:

				pass
		else:

			value=value.split(' ')
			temp_dict[value[1]]=[]
			tem=[]
			try:
				
				l=set()
				l=set(posting_lists[value[1]])
				lis=list(l)
				for a in universal:
					val=0
					for b in lis:
						comparisions+=1
						if a==b:
							val=1
							break
					if val==0:
						tem.append(a)
				tem.sort()
				temp_len[value[1]]=len(tem)
				
			except:
				tem=universal
				tem=list(tem)
				tem.sort()
				temp_len[value[1]]=len(universal)
				
			try:
				
				temp_dict[value[1]]=tem
			except:
				pass

	'''for key in temp_dict:
		print key," ",temp_dict[key],temp_len[key]'''


	sorted_list = sorted(temp_len.items(), key=operator.itemgetter(1))
	#print sorted_list
	'''for key in temp_dict:
		print key,temp_dict[key]'''
	
	if(len(sorted_list)==1):
		#print temp_dict[sorted_list[0][0]]
		return temp_dict[sorted_list[0][0]]
	else:
		l1=temp_dict[sorted_list[0][0]]
		l2=temp_dict[sorted_list[1][0]]
		l3=[]
		i=0
		j=0
		#print l1
		while(i<len(l1) and j<len(l2)):
			comparisions+=1
			if l1[i]<l2[j]:
				i+=1
			elif l1[i]==l2[j]:
				l3.append(l1[i])
				i+=1
				j+=1
			else:
				j+=1
		
		final=[]
		for i in l3:
			final.append(i)

		for i in range(2,len(sorted_list)):
			l1=temp_dict[sorted_list[i][0]]
			l3=[]
			i=0
			j=0
			#print l1
			while(i<len(l1) and j<len(final)):
				comparisions+=1
				if l1[i]<final[j]:
					i+=1
				elif l1[i]==final[j]:
					l3.append(l1[i])
					i+=1
					j+=1
				else:
					j+=1
			final=[]
			final.extend(l3)
		#print final
		return final


def query_splitting(query):
	global posting_lists;global list_length;global doc_ids;global comparisions
	#print posting_lists['asking'],"ghjk"
	#print doc_ids
	and_list=[]
	universal=set()
	for i in range(1,len(doc_ids)+1):
		universal.add(i)
	
	split_query=query.split('or');split_query=[i.strip() for i in split_query]
	#print split_query
	'''if(len(split_query)==1):
		try:
			print posting_lists[split_query[0]],comparisions###################
		except:
			print "no match found"


	else:'''
	#print split_query
	for value in split_query:
		v1=and_handle(value,universal)
		#if len(v1)!=0:
				#print value
		and_list.append(v1)
	#print and_list,comparisions
	final_list=[]
	for num in and_list:
		t=[]
		t.append(len(num))
		t.append(num)
		final_list.extend([t])
	final_list.sort()
	#print final_list,comparisions
	if len(final_list)==1:
		print "Document ids are ",final_list[0][1]
		print "number of documents are ",len(final_list[0][1])
		print "Number of comparisions are ",comparisions########################################
		print "documents selected are "
		for i in final_list[0][1]:
			print i,"->",doc_ids[i]
		return
	if len(final_list)==0:
		print "no match"
		print "number of comparisions are ",comparisions
		return
	l1=final_list[0][1]
	l2=final_list[1][1]
	l3=[]
	i=0
	j=0
		#print l1
	while(i<len(l1) and j<len(l2)):
		comparisions+=1
		if l1[i]<l2[j]:
			l3.append(l1[i])
			i+=1
		elif l1[i]==l2[j]:
			l3.append(l1[i])
			i+=1
			j+=1
		else:
			l3.append(l2[j])
			j+=1
	if(i==len(l1)):
		for k in range(j,len(l2)):
			l3.append(l2[k])
	if(j==len(l2)):
		for k in range(i,len(l1)):
			l3.append(l1[k])



	final=[]
	for i in l3:
		final.append(i)

	for i in range(2,len(final_list)):
		l1=final_list[i][1]
		l3=[]
		i=0
		j=0
			#print l1
		while(i<len(l1) and j<len(final)):
			comparisions+=1
			if l1[i]<final[j]:
				l3.append(l1[i])
				i+=1
			elif l1[i]==final[j]:
				l3.append(l1[i])
				i+=1
				j+=1
			else:
				l3.append(final[j])
				j+=1
		if(i==len(l1)):
			for k in range(j,len(final)):
				l3.append(final[k])
		if(j==len(final)):
			for k in range(i,len(l1)):
				l3.append(l1[k])

		final=[]
		final.extend(l3)
	#print final,comparisions	####################################################
	print "list of doc ids are ",final
	print "number of documents are ",len(final)
	print "number of comparisions are ",comparisions
	print "documents selected are "
	for i in final:
		print i,"->",doc_ids[i]
	
		





print "enter the query"
query=raw_input()
#query='want or say and not red' 
query=query.lower()
load_data()
query_splitting(query)